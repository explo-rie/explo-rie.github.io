// =============================================================
//  PALABRAS DEL MAPA  ✏️  ¡Este es TU archivo!
//  Aquí está todo el contenido. El mapa lo lee y lo dibuja solo.
//
//  Cómo funciona cada línea:
//     "País": ["palabra más usada", "otra palabra", "palabra (dónde se usa)"],
//
//  - La PRIMERA palabra de la lista sale grande: es la más habitual.
//  - Lo que pongas entre paréntesis sale en pequeño, como nota.
//  - Si un país no aparece en la lista, sale como «Todavía no lo sabemos».
//  - Cuidado con las comillas "" y las comas: cada línea termina en coma.
// =============================================================

const PALABRAS = {

  // ---------------------------------------------------------
  palomitas: {
    titulo: "palomitas",                 // lo que se ve en el botón
    pregunta: "¿Cómo se dicen las palomitas en…?",
    paises: {
      "México":               ["palomitas", "palomitas de maíz"],
      "Guatemala":            ["poporopos", "palomitas"],
      "El Salvador":          ["palomitas", "poporopos"],
      "Honduras":             ["palomitas de maíz", "palomitas"],
      "Nicaragua":            ["palomitas de maíz", "palomitas"],
      "Costa Rica":           ["palomitas", "palomitas de maíz"],
      "Panamá":               ["millo", "palomitas de maíz", "popcorn"],
      "Cuba":                 ["rositas de maíz", "rositas"],
      "República Dominicana": ["cocalecas", "rositas de maíz", "palomitas de maíz"],
      "Puerto Rico":          ["popcorn", "poscón", "rosetas de maíz"],
      "Venezuela":            ["cotufas"],
      "Colombia":             ["crispetas", "maíz pira", "palomitas", "maíz tote (Cundinamarca y Boyacá)"],
      "Ecuador":              ["canguil"],
      "Perú":                 ["canchita", "popcorn"],
      "Bolivia":              ["pipocas", "pororó (Santa Cruz y Tarija)"],
      "Chile":                ["cabritas", "palomitas", "popcorn"],
      "Argentina":            ["pochoclo", "pororó (noreste y Santa Fe)", "pururú (Córdoba)", "ancua (noroeste)", "pipoca (Misiones)"],
      "Paraguay":             ["pororó"],
      "Uruguay":              ["pop", "pororó"],
      "España":               ["palomitas", "palomitas de maíz"],
      "Islas Canarias":       ["cotufas (Tenerife, La Palma, La Gomera y El Hierro)", "roscas (Gran Canaria, Lanzarote y Fuerteventura)"],
      "Guinea Ecuatorial":    ["palomitas"],
    },
  },

  // Para añadir otra palabra más adelante, copia el bloque de arriba
  // (desde  palomitas: {  hasta su  },  ) y pégalo aquí con otro nombre.

};
